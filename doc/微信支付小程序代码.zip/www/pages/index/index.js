//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },





  /* 微信支付 */
  wxpay: function () {
    console.log(123);
    var that = this
    //登陆获取code 
    wx.login({
      success: function (res) {
        console.log(res.code)
        //获取openid 
        that.getOpenId(res.code)

      }
    });
  },


  getOpenId: function (code) {
    var that = this;
    wx.request({
      url: 'http://localhost:9800/wxpay/login?code=' + code,
      data: {},
      method: 'GET',
      success: function (res) {
        console.log('返回openId')
        console.log(res)
        console.log(res.data.data)
        that.generateOrder(res.data.data)
      },
      fail: function () {
        // fail 
      },
      complete: function () {
        // complete 
      }
    })
  },



  /**生成商户订单 */
  generateOrder: function (openid) {
    var that = this
    //统一支付 
    wx.request({
      url: 'http://localhost:9800/wxpay/buy',
      method: 'POST',
      data: {
        id: '1',
        openId: openid
      },
      success: function (res) {
        console.log("统一下单成功")
        console.log(res.data.data)
        var pay = res.data.data
        //发起支付 
        var timeStamp = pay.timeStamp;
        console.log("timeStamp:" + timeStamp)
        var packages = pay.prepay_id;
        console.log("package:" + packages)
        var paySign = pay.sign;
        console.log("paySign:" + paySign)
        var nonceStr = pay.nonceStr;
        console.log("nonceStr:" + nonceStr)
        var param = { "timeStamp": timeStamp, "package": packages, "paySign": paySign, "signType": "MD5", "nonceStr": nonceStr };
        console.log(param)
        that.pay(param)
      },
    })
  },


  /* 支付   */
  pay: function (param) {
    console.log("支付")
    console.log(param)
    wx.requestPayment({
      timeStamp: param.timeStamp,
      nonceStr: param.nonceStr,
      package: param.package,
      signType: param.signType,
      paySign: param.paySign,
      success: function (res) {
        // success 
        console.log("支付")
        console.log(res)
        wx.navigateBack({
          delta: 1, // 回退前 delta(默认为1) 页面 
          success: function (res) {
            wx.showToast({
              title: '支付成功',
              icon: 'success',
              duration: 2000
            })
          },
          fail: function () {
            // fail 
          },
          complete: function () {
            // complete 
          }
        })
      },
      fail: function (res) {
        // fail 
        console.log("支付失败")
        console.log(res)
      },
      complete: function () {
        // complete 
        console.log("pay complete")
      }
    })
  }
})
